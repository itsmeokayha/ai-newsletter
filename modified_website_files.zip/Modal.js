
import React from 'react';
import './Modal.css'; // Assuming you have a separate CSS file for modal styles

const Modal = ({ article, onClose }) => {
    if (!article) return null;

    return (
        <div className="modal-overlay" onClick={onClose}>
            <div className="modal-content" onClick={e => e.stopPropagation()}>
                <h1>{article.title}</h1>
                <img src={article.imageUrl} alt={article.title} />
                <p>{article.body}</p>
                {article.additionalImages && article.additionalImages.map((image, index) => (
                    <img key={index} src={image} alt={`Additional ${index}`} />
                ))}
                <button onClick={onClose}>Close</button>
            </div>
        </div>
    );
};

export default Modal;


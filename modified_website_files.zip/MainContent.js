
import React, { useState } from 'react';
const ArticleCard = React.lazy(() => import('./ArticleCard'));
const Modal = React.lazy(() => import('./Modal'));

function MainContent() {
    const [expandedArticle, setExpandedArticle] = useState(null);

    const articles = [
        { id: 1, title: 'Article 1', summary: 'Summary of Article 1', imageUrl: 'images/jan-26/art1.png', body: 'Full body of Article 1', additionalImages: ['images/jan-26/more1.png', 'images/jan-26/more2.png'] },
        { id: 2, title: 'Article 2', summary: 'Summary of Article 2', imageUrl: 'images/jan-26/art2.png', body: 'Full body of Article 2', additionalImages: ['images/jan-26/more1.png', 'images/jan-26/more2.png'] },
        { id: 3, title: 'Article 3', summary: 'Summary of Article 3', imageUrl: 'images/jan-26/art3.png', body: 'Full body of Article 3', additionalImages: ['images/jan-26/more1.png', 'images/jan-26/more2.png'] }
    ];

    const handleArticleClick = (articleId) => {
        const newExpandedArticle = expandedArticle === articleId ? null : articleId;
        setExpandedArticle(newExpandedArticle);
    };
        setExpandedArticle(article);
    };

    return (
        <main className='flex flex-col items-center justify-center p-4'>
            <React.Suspense fallback={<div>Loading...</div>}>
                <div className='articles-container'>
                    {articles.map((article) => (
                        <div key={article.id} className='article-card' onClick={() => handleArticleClick(article)}>
                            <ArticleCard isExpanded={article.id === expandedArticle}
                                title={article.title}
                                summary={article.summary}
                                imageUrl={article.imageUrl}
                            />
                        </div>
                    ))}
                </div>
                {expandedArticle && (
                    <Modal article={expandedArticle} onClose={() => setExpandedArticle(null)} />
                )}
            </React.Suspense>
        </main>
    );
}

export default MainContent;


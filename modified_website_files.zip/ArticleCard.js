import React from 'react';

function ArticleCard({ title, summary, imageUrl, altText }) {
    // Ensure the image URL is correct. It should be relative to the public folder
    const imagePath = process.env.PUBLIC_URL + '/' + imageUrl;

    function ArticleCard({ title, summary, imageUrl, altText, isExpanded }) {
    const articleClass = `article-card ${isExpanded ? 'expanded-article' : ''}`;
    return (
        <div className={articleClass}
                       sm:max-w-md md:max-w-lg lg:max-w-xl
                       transition duration-500 ease-in-out transform hover:-translate-y-1 hover:scale-105">
            <img className="w-full" src={imagePath} alt={altText ? altText : title} />
            <div className="px-6 py-4">
                <div className="font-bold text-xl mb-2">{title}</div>
                <p className="text-gray-700 text-base">
                    {summary}
                </p>
            </div>
        </div>
    );
}

export default ArticleCard;

    .expanded-article {
        transition: max-height 0.5s ease-out, transform 0.5s ease-out;
        max-height: 800px; /* Maximum height when expanded */
    }
